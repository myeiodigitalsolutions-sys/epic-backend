Edenberg University Export Report
===============================

Export Type: student
Generated: 2025-12-09T05:59:53.393Z
Total Staff: 0
Total Students: 1
Total Classes: 2

This ZIP file contains:
1. student_data.csv - Main data file
2. creation_timestamps.csv - Timestamps of all creations
3. class_creations.csv - Class creation records

CREATION TIMELINE
-----------------

Staff Members Created:


Students Created:
1. smith (m@gmail.com) - Created: December 9, 2025 at 10:49:14 AM

Classes Created:
1. Maths by moorthy18 - Created: December 9, 2025 at 11:04:57 AM
2. maths by moorthy18 - Created: December 9, 2025 at 11:29:17 AM

--- End of Report ---