Edenberg University STUDENT Export
========================================

Export Date: 12/8/2025 5:27:11 PM
Total students: 1143
Includes Passwords: Yes

This file contains sensitive information. Please handle with care.

For any questions, contact the Edenberg University IT Department.